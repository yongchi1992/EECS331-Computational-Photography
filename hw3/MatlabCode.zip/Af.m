Afres = DeNoFlash .* ((Flash + 0.2) ./ (DeFlash + 0.2));
imshow(Afres);